OkHttp Android
==============

Enhanced APIs for using OkHttp on Android.

At the moment, this will mostly likely only be useful for fastFallback.

Download
--------

```kotlin
implementation("com.squareup.okhttp3:okhttp-android:4.12.0")
```
