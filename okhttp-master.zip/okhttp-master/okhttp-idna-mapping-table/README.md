OkHttp IDNA Mapping Table
=========================

This module contains supporting tools for building the IDNA mapping table.

It is not required for runtime IDN mappings.
