OkHttp java.net.CookieHandler
=============================

This module integrates OkHttp with `CookieHandler` from `java.net`.
This used to be part of `okhttp-urlconnection`

### Download

```kotlin
testImplementation("com.squareup.okhttp3:okhttp-java-net-cookiehandler:4.12.0")
```
