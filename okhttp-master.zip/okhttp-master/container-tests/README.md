OkHttp Container Tests
======================

This module contains tests against other services
via containers.
