OkHttp URLConnection
====================

This module integrates OkHttp with `Authenticator` and `CookieHandler` from `java.net`.

This module is obsolete; prefer `okhttp-java-net-cookiejar`.

### Download

```kotlin
testImplementation("com.squareup.okhttp3:okhttp-urlconnection:4.12.0")
```
